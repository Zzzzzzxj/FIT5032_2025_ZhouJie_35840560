<template>
  <div class="about text-center"> <h1>About Our Library</h1>
    <p>Welcome to our digital library! We're dedicated to providing a vast collection of books and resources to our community.</p>
  </div>
</template>

<script setup>
</script>

<style>

</style>