module.exports = {
    publicPath: process.env.NODE_ENV === 'production'
      ? '/FIT5032_2025_ZhouJie_35840560/'
      : '/'
  }